package Ejemplo6_Sillas;

abstract public class color extends prices {
    @Override
    abstract public void color();
}

