package Ejemplo6_Sillas;

public interface specifications {
    void haslegs();
    void sitOn();
    void price();
    void color();
}

