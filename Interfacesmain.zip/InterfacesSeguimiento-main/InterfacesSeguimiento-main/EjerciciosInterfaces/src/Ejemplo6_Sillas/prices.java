package Ejemplo6_Sillas;

abstract public class prices implements specifications {

    @Override
    abstract public void price() ;
}
